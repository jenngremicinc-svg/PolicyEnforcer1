import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import path from 'path';
import {defineConfig} from 'vite';

// NOTE: no secrets are injected into the client bundle.
// Gemini is called server-side via /api/gemini (netlify/functions/gemini.ts).
export default defineConfig({
  plugins: [react(), tailwindcss()],
  resolve: {
    alias: {'@': path.resolve(__dirname, '.')},
  },
});
