import {GoogleGenAI} from '@google/genai';
import type {Config} from '@netlify/functions';

const MODEL = process.env.GEMINI_MODEL || 'gemini-2.5-flash';
const MAX_PROMPT_CHARS = 8000;
// Comma-separated list, e.g. "https://your-site.netlify.app,https://yourdomain.com"
const ALLOWED_ORIGINS = (process.env.ALLOWED_ORIGINS || '')
  .split(',')
  .map((s) => s.trim())
  .filter(Boolean);

const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), {
    status,
    headers: {'Content-Type': 'application/json', 'Cache-Control': 'no-store'},
  });

export default async (req: Request) => {
  if (req.method !== 'POST') return json({error: 'Method not allowed'}, 405);

  // Basic origin check (not a substitute for auth/rate limiting)
  const origin = req.headers.get('origin');
  if (ALLOWED_ORIGINS.length && (!origin || !ALLOWED_ORIGINS.includes(origin))) {
    return json({error: 'Forbidden'}, 403);
  }

  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) return json({error: 'Server not configured'}, 500);

  let prompt: unknown;
  try {
    ({prompt} = await req.json());
  } catch {
    return json({error: 'Invalid JSON'}, 400);
  }
  if (typeof prompt !== 'string' || !prompt.trim() || prompt.length > MAX_PROMPT_CHARS) {
    return json({error: 'Invalid prompt'}, 400);
  }

  try {
    const ai = new GoogleGenAI({apiKey});
    const res = await ai.models.generateContent({model: MODEL, contents: prompt});
    return json({text: res.text ?? ''});
  } catch (err) {
    console.error('Gemini error', err);
    return json({error: 'Upstream error'}, 502);
  }
};

export const config: Config = {path: '/api/gemini'};
