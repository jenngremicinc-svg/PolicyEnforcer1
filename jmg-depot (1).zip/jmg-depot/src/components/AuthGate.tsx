import {useEffect, useState, type ReactNode} from 'react';
import type {Session} from '@supabase/supabase-js';
import {supabase} from '../lib/supabase';

export default function AuthGate({children}: {children: (s: Session) => ReactNode}) {
  const [session, setSession] = useState<Session | null>(null);
  const [loading, setLoading] = useState(true);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    supabase.auth.getSession().then(({data}) => {
      setSession(data.session);
      setLoading(false);
    });
    const {data: sub} = supabase.auth.onAuthStateChange((_e, s) => setSession(s));
    return () => sub.subscription.unsubscribe();
  }, []);

  async function signIn(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError('');
    const {error} = await supabase.auth.signInWithPassword({email, password});
    if (error) setError(error.message);
    setBusy(false);
  }

  if (loading) return <div style={{padding: 24}}>Loading…</div>;

  if (!session) {
    return (
      <form onSubmit={signIn} style={{maxWidth: 360, margin: '15vh auto', display: 'grid', gap: 12, padding: 16}}>
        <h1 style={{fontSize: 20, fontWeight: 600}}>Sign in</h1>
        <input type="email" required autoComplete="email" placeholder="Email" value={email}
          onChange={(e) => setEmail(e.target.value)} style={{padding: 10, border: '1px solid #ccc', borderRadius: 6}} />
        <input type="password" required autoComplete="current-password" placeholder="Password" value={password}
          onChange={(e) => setPassword(e.target.value)} style={{padding: 10, border: '1px solid #ccc', borderRadius: 6}} />
        {error && <div role="alert" style={{color: '#b00020', fontSize: 14}}>{error}</div>}
        <button disabled={busy} style={{padding: 10, borderRadius: 6, background: '#111', color: '#fff'}}>
          {busy ? 'Signing in…' : 'Sign in'}
        </button>
      </form>
    );
  }

  return <>{children(session)}</>;
}
