import {supabase} from './supabase';

export async function askGemini(prompt: string): Promise<string> {
  const {data} = await supabase.auth.getSession();
  const token = data.session?.access_token;
  if (!token) throw new Error('Not signed in');

  const res = await fetch('/api/gemini', {
    method: 'POST',
    headers: {'Content-Type': 'application/json', Authorization: `Bearer ${token}`},
    body: JSON.stringify({prompt}),
  });
  if (!res.ok) throw new Error(`Request failed (${res.status})`);
  return (await res.json()).text as string;
}
