import {createClient} from '@supabase/supabase-js';

// The anon key is designed to be public. Real protection comes from
// Supabase Auth settings + Row Level Security + server-side token checks.
export const supabase = createClient(
  import.meta.env.VITE_SUPABASE_URL as string,
  import.meta.env.VITE_SUPABASE_ANON_KEY as string,
);
