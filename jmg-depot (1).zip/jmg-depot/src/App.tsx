/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */
import AuthGate from './components/AuthGate';
import {supabase} from './lib/supabase';

export default function App() {
  return (
    <AuthGate>
      {(session) => (
        <div style={{padding: 24}}>
          <p>Signed in as {session.user.email}</p>
          <button onClick={() => supabase.auth.signOut()}>Sign out</button>
          {/* Depot app goes here */}
        </div>
      )}
    </AuthGate>
  );
}
