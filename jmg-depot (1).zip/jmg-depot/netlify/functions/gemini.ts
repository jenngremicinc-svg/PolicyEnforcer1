import {GoogleGenAI} from '@google/genai';
import {createClient} from '@supabase/supabase-js';
import type {Config} from '@netlify/functions';

const MODEL = process.env.GEMINI_MODEL || 'gemini-2.5-flash';
const MAX_PROMPT_CHARS = 8000;
const list = (v?: string) => (v || '').split(',').map((s) => s.trim().toLowerCase()).filter(Boolean);
const ALLOWED_ORIGINS = list(process.env.ALLOWED_ORIGINS);
const ALLOWED_EMAILS = list(process.env.ALLOWED_EMAILS); // optional invite-only allowlist

const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), {
    status,
    headers: {'Content-Type': 'application/json', 'Cache-Control': 'no-store'},
  });

export default async (req: Request) => {
  if (req.method !== 'POST') return json({error: 'Method not allowed'}, 405);

  const origin = (req.headers.get('origin') || '').toLowerCase();
  if (ALLOWED_ORIGINS.length && !ALLOWED_ORIGINS.includes(origin)) {
    return json({error: 'Forbidden'}, 403);
  }

  // --- Authenticate: verify the Supabase JWT server-side ---
  const token = req.headers.get('authorization')?.replace(/^Bearer\s+/i, '');
  if (!token) return json({error: 'Unauthorized'}, 401);

  const sbUrl = process.env.SUPABASE_URL || process.env.VITE_SUPABASE_URL;
  const sbKey = process.env.SUPABASE_ANON_KEY || process.env.VITE_SUPABASE_ANON_KEY;
  const apiKey = process.env.GEMINI_API_KEY;
  if (!sbUrl || !sbKey || !apiKey) return json({error: 'Server not configured'}, 500);

  const sb = createClient(sbUrl, sbKey, {auth: {persistSession: false}});
  const {data, error} = await sb.auth.getUser(token);
  if (error || !data.user) return json({error: 'Unauthorized'}, 401);
  if (ALLOWED_EMAILS.length && !ALLOWED_EMAILS.includes((data.user.email || '').toLowerCase())) {
    return json({error: 'Forbidden'}, 403);
  }

  // --- Validate input ---
  let prompt: unknown;
  try {
    ({prompt} = await req.json());
  } catch {
    return json({error: 'Invalid JSON'}, 400);
  }
  if (typeof prompt !== 'string' || !prompt.trim() || prompt.length > MAX_PROMPT_CHARS) {
    return json({error: 'Invalid prompt'}, 400);
  }

  try {
    const ai = new GoogleGenAI({apiKey});
    const res = await ai.models.generateContent({model: MODEL, contents: prompt});
    return json({text: res.text ?? ''});
  } catch (err) {
    console.error('Gemini error', err);
    return json({error: 'Upstream error'}, 502);
  }
};

export const config: Config = {path: '/api/gemini'};
