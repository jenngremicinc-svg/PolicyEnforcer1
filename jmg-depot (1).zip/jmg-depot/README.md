# JMG REMIC Secured Asset Depot

## Local
1. `npm install`
2. `cp .env.example .env` and set `GEMINI_API_KEY`
3. `npm run dev` (Netlify Dev serves Vite + functions at http://localhost:8888)

## Deploy (Netlify)
1. Push to GitHub, then "Add new site > Import from Git" in Netlify.
2. Build settings come from `netlify.toml`.
3. Add `GEMINI_API_KEY` and `ALLOWED_ORIGINS` under Environment variables
   (mark the key as secret). Redeploy.

The browser never sees the API key: the UI calls `/api/gemini`, handled by
`netlify/functions/gemini.ts`.

## Auth (Supabase)
1. Create a Supabase project; copy the URL and anon key into the env vars above.
2. Authentication > Providers: keep Email on. **Turn OFF "Allow new users to sign up"**
   and invite users manually (Authentication > Users > Invite).
3. Enable MFA (Authentication > Multi-Factor) and set a strong password policy.
4. Set Authentication > URL Configuration > Site URL to your Netlify URL.
5. For any Supabase tables you add, enable Row Level Security and write policies.

`/api/gemini` rejects requests without a valid Supabase session token.
